-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 21, 2020 at 01:36 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE IF NOT EXISTS `userinfo` (
  `firstName` text NOT NULL,
  `lastName` text NOT NULL,
  `ssnNumber` bigint NOT NULL,
  `salary` int NOT NULL DEFAULT '0',
  `Gender` text NOT NULL,
  PRIMARY KEY (`ssnNumber`),
  UNIQUE KEY `ssnNumber` (`ssnNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`firstName`, `lastName`, `ssnNumber`, `salary`, `Gender`) VALUES
('Coral', 'Couch', 151, 4549, 'female'),
('Kajol', 'Kirk', 4308, 9848, 'male'),
('Oriana', 'Leon', 5173, 5114, 'Other'),
('Donovan', 'Campbell', 5651, 9445, 'male'),
('Isla-Rae', 'Horton', 8591, 7076, 'other'),
('Hamza', 'Rosales', 5348, 1327, 'female'),
('Brady', 'Garrett', 7548, 2334, 'male'),
('Kurtis', 'Rooney', 1396, 2707, 'other'),
('Niyah', 'Webber', 4353, 7818, 'male'),
('Cassandra', 'Harper', 5276, 7431, 'male'),
('Clyde', 'Dorsey', 5306, 8968, 'female');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
